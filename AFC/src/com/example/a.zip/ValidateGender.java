package com.example;

public class ValidateGender extends Exception {

	public ValidateGender(String message) {
		super(message);

	}

	@Override
	public String getMessage() {

		return super.getMessage();
	}
	
	

}
